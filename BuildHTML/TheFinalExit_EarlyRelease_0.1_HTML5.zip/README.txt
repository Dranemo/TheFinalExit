The Final Exit

Jeu produit par Yanaël Caillot en 2024 dans le cadre de ses études au Gaming Campus.

Ce produit ne peut pas être utilisé à des fins commerciales.

Ce jeu est fortement inspiré par le jeu Roblox Doors. Je n'ai aucun lien avec Doors ni d'autorisations de leur part.

Assets utilisés :
- Asset batterie : Flaticon
- Glitch face : https://www.pixilart.com/art/glitch-face-sr2b86f42ec81aws3
- Effets sonores : pixabay
- Effet de glitch : "Digital Glitch Abstract Pattern PNG" par tdronan sur Wallpapers.com est licencié sous CC BY 2.0.

Utilisation de GitHub Copilot pour la production de certains morceaux de code.